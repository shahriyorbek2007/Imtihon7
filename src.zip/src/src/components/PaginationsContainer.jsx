import React from 'react'

function PaginationsContainer() {
  return (
    <div>PaginationsContainer</div>
  )
}

export default PaginationsContainer