import React from 'react'

function Filters() {
  return (
    <div>Filters</div>
  )
}

export default Filters