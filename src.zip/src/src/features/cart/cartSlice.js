import { createSlice } from "@reduxjs/toolkit";
import { Toast } from "react-toastify/dist/components";
const defaultState = {
  cartItems: [],
  numItemInCart: 0,
  cardTotal: 0,
  shipping: 0,
  yax: 0, //10%
  orderTotal: 0,
};
const cartSlice = createSlice({
  name: "cart",
  initialState: defaultState,
  reducers: {
    addItem: (state, action) => {
      console.log(action.payload);
    },
    clearCart: (state, action) => {},
    removeItem: (state, action) => {},
    editItem: (state, action) => {},
  },
});
export const { addItem, clearCart, removeItem, editItem } = cartSlice.actions;
export default cartSlice.reducer;